package com.example.taten.chivasa_cardiobook;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private ArrayList<Measurement> mlist;
    private OnItemClickListener mylistener;

    public interface OnItemClickListener{
        void onItemClick(int position);
        void onDeleteClick(int position);

    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mylistener = listener;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView tv1;
        public TextView tv2;
        public TextView tv3;
        public TextView tv4;
        public TextView tv5;
        public TextView tv6;
        public ImageView del;
        public ImageView ed1;


        public MyViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);
            tv1 = itemView.findViewById(R.id.textView);
            tv2 = itemView.findViewById(R.id.textView2);
            tv3 = itemView.findViewById(R.id.textView3);
            tv4 = itemView.findViewById(R.id.textView4);
            tv5 = itemView.findViewById(R.id.textView5);
            tv6 = itemView.findViewById(R.id.textView6);
            del = itemView.findViewById(R.id.image_delete);
            ed1 = itemView.findViewById(R.id.image_edit);

            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);


                        }

                    }

                }
            });

            del.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    if (listener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            listener.onDeleteClick(position);
                        }
                    }
                }
            });
        }
    }



    public MyAdapter(ArrayList<Measurement> mdata){
        mlist = mdata;

    }

    //@NonNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int ViewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.theview,parent,false);
        MyViewHolder mvh = new MyViewHolder(v, mylistener);
        return mvh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Measurement currentItem = mlist.get(position);

        holder.tv1.setText(currentItem.getMdate());
        holder.tv2.setText(currentItem.getMtime());
        holder.tv3.setText(String.valueOf(currentItem.getSystolic_pressure()));
        holder.tv4.setText(String.valueOf(currentItem.getDiastolic_pressure()));
        holder.tv5.setText(String.valueOf(currentItem.getHeartrate()));
        holder.tv6.setText(String.valueOf(currentItem.getCcomment()));

    }

    @Override
    public int getItemCount() {
        return mlist.size();
    }
}
