package com.example.taten.chivasa_cardiobook;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class Addm extends AppCompatActivity {

    private Button button;

    private ArrayList<Measurement> mylist;

    private EditText editdat;
    private EditText edittim;
    private EditText editsys;
    private EditText editdia;
    private EditText editheart;
    private EditText editcomm;

    private Button buttonsave;

    private RecyclerView.Adapter myAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        button = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backtomain();

            }
        });

        buttonsave = findViewById(R.id.button3);
        buttonsave.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //insert(mylist);
                savedata();
                loadData();
            }
        });

        editdat = findViewById(R.id.editdate);
        edittim = findViewById(R.id.edittime);
        editsys = findViewById(R.id.editspressure);
        editdia = findViewById(R.id.editdpressure);
        editheart = findViewById(R.id.edithrate);
        editcomm = findViewById(R.id.editcomment);


        }
    private void savedata() {
        SharedPreferences sharedpreferences = getSharedPreferences("shared preferences",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(mylist);
        editor.putString("task list", json);
        editor.apply();
    }

    private void loadData(){
        SharedPreferences sharedpreferences = getSharedPreferences("shared preferences",MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedpreferences.getString("task list",null);
        Type type = new TypeToken<ArrayList<Measurement>>() {}.getType();
        mylist = gson.fromJson(json, type);

        if (mylist == null){
            mylist = new ArrayList<>();
        }

    }

    public void backtomain(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }

    /*public void insert (ArrayList<Measurement> mydata) {

        mylist = mydata;
        int position = mydata.size();
        String ndate = editdat.getText().toString();
        String ntime = edittim.getText().toString();
        int nsys = Integer.parseInt(editsys.getText().toString());
        int ndia = Integer.parseInt(editdia.getText().toString());
        int nheart = Integer.parseInt(editheart.getText().toString());
        String ncomm = editcomm.getText().toString();




        mylist.add(position, new Measurement(ndate,ntime,nsys,ndia,nheart,ncomm));
        myAdapter.notifyItemInserted(position);

        }*/
    }

