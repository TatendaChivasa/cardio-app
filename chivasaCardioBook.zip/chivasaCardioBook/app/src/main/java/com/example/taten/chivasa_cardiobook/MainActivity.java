package com.example.taten.chivasa_cardiobook;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private ArrayList<Measurement>mdata;

    private RecyclerView myRecyclerView;
    private MyAdapter myAdapter;
    private RecyclerView.LayoutManager myLayoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createdataList();
        buildRecyclerview();

        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddm();
            }
        });

    }

        public void openAddm(){
            Intent intent = new Intent(this, Addm.class);
            startActivity(intent);

        }

        public void removeItem(int position){
            mdata.remove(position);
            myAdapter.notifyItemRemoved(position);
        }

        public void changeItem(int position, String text){
            mdata.get(position).changeText1(text);
            myAdapter.notifyItemChanged(position);


        }

        public void createdataList(){
            Measurement m1 = new Measurement("2019-09-09","0300",100,90,70,"Comment: ");
            Measurement m2 = new Measurement("2003-10-29","1750",140,60,90,"Comment: ");
            //Measurement m3 = new Measurement("2005-12-13","1530",90,100,120,"Comment: ");
            //Measurement m4 = new Measurement("2012-03-09","2300",150,50,50,"Comment: ");
            //Measurement m5 = new Measurement("2018-09-10","2200",80,75,80,"Comment: ");
            //Measurement m6 = new Measurement("2020-03-12","0000",10,90,55,"Comment: ");
            //Measurement m7 = new Measurement("2021-12-10","1921",10,125,77,"Comment: ");

            mdata = new ArrayList<>();
            mdata.add(m1);
            mdata.add(m2);
            //mdata.add(m3);
            //mdata.add(m4);
            //mdata.add(m5);
            //mdata.add(m6);
            //mdata.add(m7);

        }

        public void buildRecyclerview(){

            myRecyclerView = findViewById(R.id.recyclerView);
            myRecyclerView.setHasFixedSize(true);
            myLayoutManager = new LinearLayoutManager(this);
            myAdapter = new MyAdapter(mdata);
            myRecyclerView.setLayoutManager(myLayoutManager);
            myRecyclerView.setAdapter(myAdapter);

            myAdapter.setOnItemClickListener(new MyAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int position) {
                    changeItem(position, "Edit mode");
                }

                @Override
                public void onDeleteClick(int position) {
                    removeItem(position);
                }
            });


    }

        //public void deleteitem(int position){}
    }


